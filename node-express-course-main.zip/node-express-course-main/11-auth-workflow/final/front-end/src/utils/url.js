const url = 'http://localhost:5000';

export default url;
